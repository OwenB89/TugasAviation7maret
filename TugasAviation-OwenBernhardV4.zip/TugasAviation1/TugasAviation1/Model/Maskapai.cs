﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TugasAviation1.Model
{
    internal class Maskapai
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int Tipeid { get; set; }

    }
}
