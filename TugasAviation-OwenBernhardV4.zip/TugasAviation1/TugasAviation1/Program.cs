﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

//Gk ad validation jadi kalo input slah eror
//enter lagi abis input buat lanjut

using System.Collections.Generic;
using TugasAviation1.Model;

var maskapai = new List<Maskapai>();
var pesawat = new List<Pesawat>();

bool run = true;
bool show = true;
string input = String.Empty;
string insert = String.Empty;
string insert2 = String.Empty;
int idmask = 0;
int idpesa = 0;
int index = 0;

do
{
    Console.Clear();
    Console.WriteLine("Menu");
    Console.WriteLine("========================");
    Console.WriteLine("1. Master Maskapai");
    Console.WriteLine("2. Delete Maskapai");
    Console.WriteLine("3. Master Tipe Pesawat");
    Console.WriteLine("4. Mapping Maskapai Tipe Pesawat");
    Console.WriteLine("5. Tampilin Mapping Maskapai");
    Console.WriteLine("Enter 0 to back");
    Console.WriteLine("Choose options: ");
    input = Console.ReadLine();
    int menin = int.Parse(input);

    switch (menin)
    {
        case 1:
            Console.WriteLine("Enter Maskapai Name:");
            insert = Console.ReadLine();
            if (insert == "0") break;
            addMask(insert);
            Console.ReadKey();
            break;
        case 2:
            delMask();
            index = 0;
            foreach (var mask in maskapai)
            {
                mask.Id = index+1;
                index++;

            }
            Console.ReadKey();

            break;
        case 3:
            Console.WriteLine("Enter Pesawat Name:");
            insert= Console.ReadLine();
            if (insert == "0") break;
            addPesa(insert);
            Console.ReadKey();

            break;
        case 4:
            Console.WriteLine("Input Maskapai Id:");
            insert= Console.ReadLine();
            if (insert == "0") break;
            Console.WriteLine("Input Pesawat Id:");
            insert2= Console.ReadLine();
            if (insert2 == "0") break;
            idmask = int.Parse(insert);
            idpesa = int.Parse(insert2);
            mapping(idmask, idpesa);
            Console.ReadKey();

            break;
        case 5:
            var jointlist = (from mask in maskapai
                             join pesa in pesawat on mask.Tipeid equals pesa.Id into lmask
                             from pesa in lmask.DefaultIfEmpty()
                             select new
                             {
                                 Id = mask.Id,
                                 Name = mask.Name,
                                 Tipe = pesa?.Name != null ? pesa?.Name : string.Empty
                             });//.ToList();
            foreach (var mask in jointlist.ToList())
            {
                Console.WriteLine($"{mask.Id} - {mask.Name} - {mask.Tipe}");
            }
            show = true;
            do
            {
                Console.WriteLine("    1. Sort Nama Maskapai");
                Console.WriteLine("    2. Sort Tipe Maskapai");
                Console.WriteLine("    3. Filtered Search");
                Console.WriteLine("Enter 0 to return");
                insert2 = Console.ReadLine();
                int showin = int.Parse(insert2);
                switch (showin)
                {
                    case 1:
                        var fil1 = jointlist.ToList();
                        foreach (var mask in fil1.OrderBy(x => x.Name))
                        {
                            Console.WriteLine($"{mask.Id} - {mask.Name} - {mask.Tipe}");

                        }
                        break;
                    case 2:
                        var fil2 = jointlist.ToList();
                        foreach (var mask in fil2.OrderBy(x => x.Tipe))
                        {
                            Console.WriteLine($"{mask.Id} - {mask.Name} - {mask.Tipe}");

                        }
                        break;
                    case 3:
                        //var fil3 = jointlist.ToList();
                        Console.WriteLine("What are you looking for:");
                        input = Console.ReadLine();
                        // gk bisa filter tergantung tipe kalo ad yg belum punya tipe
                        // bkal muncul eror
                        var filter = jointlist.Where(x => x.Name.Contains(input) || (x.Tipe?.Contains(input)).Value).ToList();
                        foreach (var mask in filter)
                        {
                            Console.WriteLine($"{mask.Id} - {mask.Name} - {mask.Tipe}");
                        }
                        break;
                    default:
                        show = false;
                        break;
                }


            } while (show);
            Console.ReadKey();
            break;
        default:
            run = false;
            break;
    }

} while (run);

void addMask(string name)
{
    var su1 = new Maskapai
    {
        Id = maskapai.Count()+1,
        Name = name
    };

    maskapai.Add(su1);
}

void delMask()
{
    foreach (var mask in maskapai)
    {
        Console.WriteLine($"{mask.Id} - {mask.Name}");
    }
    Console.WriteLine("Input id that want to be deleted:");
    input = Console.ReadLine();
    int delin = int.Parse(input);

    if(delin == 0)
    {
        return;
    }

    maskapai.Remove(maskapai.Single(r => r.Id == delin));
    //Console.WriteLine("Maskapai Deleted!");
}

void addPesa(string name)
{
    var pe1 = new Pesawat
    {
        Id = pesawat.Count() + 1,
        Name = name
    };

    pesawat.Add(pe1);
}

void mapping(int idmask, int idpesa)
{
    foreach (var mask in maskapai)
    {
        if(mask.Id == idmask)
        {
            mask.Tipeid = pesawat.Single(r => r.Id == idpesa).Id;
        }
    }
}

void showmap()
{
    var jointlist = (from mask in maskapai
                     join pesa in pesawat on mask.Tipeid equals pesa.Id into lmask
                     from pesa in lmask.DefaultIfEmpty()
                     select new
                     {
                         Id = mask.Id,
                         Name = mask.Name,
                         Tipe = pesa.Name
                     }).ToList();
    foreach (var mask in jointlist)
    {
        Console.WriteLine($"{mask.Id} - {mask.Name} - {mask.Tipe}");

    }
}
